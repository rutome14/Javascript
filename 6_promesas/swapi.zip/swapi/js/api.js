
// async - await 
// 1 - Colocar la palabra await delante de la ejecución de la promesa
// 2 - Colocar la palabra async delante de la función donde estamos ejecutando la promesa
// 3 - El valor que recibimos en then ahora lo recibimos como una variable al ejecutar la promesa

// const ulPersonajes = document.getElementById('personajes');
const ulPersonajes = document.querySelector('#personajes');

printMenu();

async function getDataMenu() {
    const response = await fetch('https://swapi.dev/api/people/?format=json');
    const json = await response.json();
    return json.results;
}

async function printMenu() {
    const personajes = await getDataMenu()

    for (let personaje of personajes) {
        const li = document.createElement('li');
        li.innerText = personaje.name;
        ulPersonajes.appendChild(li);
    }

}
